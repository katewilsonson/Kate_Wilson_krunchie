/*
  ==============================================================================

    This file was auto-generated!

    It contains the basic framework code for a JUCE plugin editor.

  ==============================================================================
*/

#include "PluginProcessor.h"
#include "PluginEditor.h"


//==============================================================================
//setting colours and type for all the sliders
DistortionPlugInAudioProcessorEditor::DistortionPlugInAudioProcessorEditor (DistortionPlugInAudioProcessor& p)
    : AudioProcessorEditor (&p), processor (p)
{
    
    addAndMakeVisible(driveKnob = new Slider("Drive"));
    driveKnob->setSliderStyle(Slider::Rotary);
    driveKnob->setTextBoxStyle(Slider::NoTextBox, false, 100, 100);
    driveKnob->setColour (Slider::backgroundColourId, Colours::red);
    driveKnob->setColour (Slider::rotarySliderFillColourId, Colours::red);
    driveKnob->setColour (Slider::rotarySliderOutlineColourId, Colours::lightcoral);
    driveKnob->setColour (Slider::thumbColourId, Colours::white);
    
    
    addAndMakeVisible(rangeKnob = new Slider("Range"));
    rangeKnob->setSliderStyle(Slider::Rotary);
    rangeKnob->setTextBoxStyle(Slider::NoTextBox, false, 100, 100);
    rangeKnob->setColour (Slider::backgroundColourId, Colours::green);
    rangeKnob->setColour (Slider::thumbColourId, Colours::white);
    rangeKnob->setColour (Slider::trackColourId, Colour (0xff43ff00));
    rangeKnob->setColour (Slider::rotarySliderFillColourId, Colour (0xff43ff00));
    rangeKnob->setColour (Slider::rotarySliderOutlineColourId, Colours::lightgreen);
    
    addAndMakeVisible(mixKnob = new Slider("Mix"));
    mixKnob->setSliderStyle(Slider::Rotary);
    mixKnob->setTextBoxStyle(Slider::NoTextBox, false, 100, 100);
    mixKnob->setColour (Slider::backgroundColourId, Colours::blue);
    mixKnob->setColour (Slider::thumbColourId, Colours::white);
    mixKnob->setColour (Slider::rotarySliderOutlineColourId, Colours::lightskyblue);
    mixKnob->setColour (Slider::trackColourId, Colours::blue);
    mixKnob->setColour (Slider::rotarySliderFillColourId, Colours::blue);
    
    addAndMakeVisible(gainKnob = new Slider("Gain"));
    gainKnob->setSliderStyle(Slider::Rotary);
    gainKnob->setTextBoxStyle(Slider::NoTextBox, false, 100, 100);
    gainKnob->setColour (Slider::backgroundColourId, Colours::white);
    gainKnob->setColour (Slider::thumbColourId, Colours::grey);
    gainKnob->setColour (Slider::rotarySliderOutlineColourId, Colours::darkslategrey);
    gainKnob->setColour (Slider::trackColourId, Colours::white);
    gainKnob->setColour (Slider::rotarySliderFillColourId, Colours::white);
    
    driveAttachment = new AudioProcessorValueTreeState::SliderAttachment(p.getState(), "drive",*driveKnob);
    rangeAttachment = new AudioProcessorValueTreeState::SliderAttachment(p.getState(),"range",*rangeKnob);
    mixAttachment = new AudioProcessorValueTreeState::SliderAttachment(p.getState(),"mix",*mixKnob);
    gainAttachment = new AudioProcessorValueTreeState::SliderAttachment(p.getState(),"gain,",*gainKnob);

    
    
    // Make sure that before the constructor has finished, you've set the
    // editor's size to whatever you need it to be.
    //set size of the window
    setSize (500, 300);
}

DistortionPlugInAudioProcessorEditor::~DistortionPlugInAudioProcessorEditor()
{
}

//==============================================================================
//setting colours for background, text and boxes
void DistortionPlugInAudioProcessorEditor::paint (Graphics& g)
{
    g.fillAll(Colours::black);
    
    {
        float x = 7.0f, y = 7.0f, width = 487.0f, height = 287.0f;
        Colour fillColour = Colours::black;
        Colour strokeColour = Colour (0xfff9ea2f);
        //[UserPaintCustomArguments] Customize the painting arguments here..
        //[/UserPaintCustomArguments]
        g.setColour (fillColour);
        g.fillRoundedRectangle (x, y, width, height, 10.000f);
        g.setColour (strokeColour);
        g.drawRoundedRectangle (x, y, width, height, 10.000f, 5.000f);
    }
    {
    float x =55.0f, y = 103.0f, width = 90.0f, height = 90.0f;
    Colour fillColour = Colours::black;
    Colour strokeColour = Colours::white;
    //[UserPaintCustomArguments] Customize the painting arguments here..
    //[/UserPaintCustomArguments]
    g.setColour (fillColour);
    g.fillRoundedRectangle (x, y, width, height, 10.000f);
    g.setColour (strokeColour);
    g.drawRoundedRectangle (x, y, width, height, 5.000f, 5.000f);
    }
    {
    float x =155.0f, y = 103.0f, width = 90.0f, height = 90.0f;
    Colour fillColour = Colours::black;
    Colour strokeColour = Colours::white;
    //[UserPaintCustomArguments] Customize the painting arguments here..
    //[/UserPaintCustomArguments]
    g.setColour (fillColour);
    g.fillRoundedRectangle (x, y, width, height, 10.000f);
    g.setColour (strokeColour);
    g.drawRoundedRectangle (x, y, width, height, 5.000f, 5.000f);
    }
    {
        float x =255.0f, y = 103.0f, width = 90.0f, height = 90.0f;
        Colour fillColour = Colours::black;
        Colour strokeColour = Colours::white;
        //[UserPaintCustomArguments] Customize the painting arguments here..
        //[/UserPaintCustomArguments]
        g.setColour (fillColour);
        g.fillRoundedRectangle (x, y, width, height, 10.000f);
        g.setColour (strokeColour);
        g.drawRoundedRectangle (x, y, width, height, 5.000f, 5.000f);
    }
    {
        float x =355.0f, y = 103.0f, width = 90.0f, height = 90.0f;
        Colour fillColour = Colours::black;
        Colour strokeColour = Colours::white;
        //[UserPaintCustomArguments] Customize the painting arguments here..
        //[/UserPaintCustomArguments]
        g.setColour (fillColour);
        g.fillRoundedRectangle (x, y, width, height, 10.000f);
        g.setColour (strokeColour);
        g.drawRoundedRectangle (x, y, width, height, 5.000f, 5.000f);
    }
   
    
    {
        int x = 185, y = 34, width = 124, height = 30;
        String text (TRANS("Krunchie"));
        Colour fillColour = Colours::white;
        //[UserPaintCustomArguments] Customize the painting arguments here..
        //[/UserPaintCustomArguments]
        g.setColour (fillColour);
        g.setFont (Font ("GoodDog Cool", 40.00f, Font::plain).withTypefaceStyle ("Regular"));
        g.drawText (text, x, y, width, height,
                    Justification::centred, true);
    }
    {
        int x = 20, y = 250, width = 124, height = 30;
        String text (TRANS("@adrawingbykate"));
        Colour fillColour = Colours::white;
        //[UserPaintCustomArguments] Customize the painting arguments here..
        //[/UserPaintCustomArguments]
        g.setColour (fillColour);
        g.setFont (Font ("GoodDog Cool", 20.00f, Font::plain).withTypefaceStyle ("Regular"));
        g.drawText (text, x, y, width, height,
                    Justification::centred, true);
    }
    // (Our component is opaque, so we must completely fill the background with a solid colour)
    //g.fillAll (getLookAndFeel().findColour (ResizableWindow::backgroundColourId));

   // g.setColour (Colours::blue);
    //g.setFont (15.0f);
   // g.drawFittedText ("Hello World!", getLocalBounds(), Justification::centred, 1);
}

void DistortionPlugInAudioProcessorEditor::resized()
{
    //setting position of sliders
    driveKnob->setBounds(((getWidth() / 5) * 1) - (100 / 2), (getHeight() / 2) - (100 / 2), 100,100);
    rangeKnob->setBounds(((getWidth() / 5) * 2) - (100 / 2), (getHeight() / 2) - (100 / 2), 100,100);
    mixKnob->setBounds(((getWidth() / 5) * 3) - (100 / 2), (getHeight() / 2) - (100 / 2), 100,100);
    gainKnob->setBounds(((getWidth() / 5) * 4) - (100 / 2), (getHeight() / 2) - (100 / 2), 100,100);

}
