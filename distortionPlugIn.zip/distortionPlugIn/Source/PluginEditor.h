/*
  ==============================================================================

    This file was auto-generated!

    It contains the basic framework code for a JUCE plugin editor.

  ==============================================================================
*/

#pragma once

#include "../JuceLibraryCode/JuceHeader.h"
#include "PluginProcessor.h"


//==============================================================================
/**
*/
class DistortionPlugInAudioProcessorEditor  : public AudioProcessorEditor
{
public:
    DistortionPlugInAudioProcessorEditor (DistortionPlugInAudioProcessor&);
    ~DistortionPlugInAudioProcessorEditor();

    //==============================================================================
   
    //declaring all the sliders
    void paint (Graphics&) override;
    void resized() override;

private:
    
    ScopedPointer<Slider> driveKnob;
    ScopedPointer<Slider> rangeKnob;
    ScopedPointer<Slider> mixKnob;
    ScopedPointer<Slider> gainKnob;
    
    ScopedPointer<AudioProcessorValueTreeState::SliderAttachment> driveAttachment;
    ScopedPointer<AudioProcessorValueTreeState::SliderAttachment> rangeAttachment;
    ScopedPointer<AudioProcessorValueTreeState::SliderAttachment> mixAttachment;
    ScopedPointer<AudioProcessorValueTreeState::SliderAttachment> gainAttachment;
    
    
    // This reference is provided as a quick way for your editor to
    // access the processor object that created it.
    DistortionPlugInAudioProcessor& processor;


    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (DistortionPlugInAudioProcessorEditor)
};
